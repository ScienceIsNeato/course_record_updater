# MCP (Model Context Protocol) Configuration

This directory contains MCP server configurations that enhance the AI assistant's capabilities.

## Current Servers

### Sequential Thinking
- **Purpose**: Provides structured, step-by-step problem-solving capabilities
- **Cost**: Free (open source, MIT license)
- **Usage**: Automatic - the AI will use it when appropriate for complex problems

### GitHub Integration
- **Purpose**: Enables direct GitHub repository interactions for automated workflows
- **Cost**: Free (requires GitHub Personal Access Token)
- **Features**: Repository management, file operations, issue tracking, PR management
- **Setup Required**: Personal Access Token configuration

## Setup Instructions

### GitHub Server Setup
1. **Create Personal Access Token:**
   - Go to GitHub → Settings → Developer settings → Personal access tokens
   - Generate new token with appropriate permissions (repo, read:org, etc.)

2. **Configure Token:**
   - Set `GITHUB_PERSONAL_ACCESS_TOKEN` environment variable
   - Or update the token in your local `.cursor/mcp.json` file

3. **Required Permissions:**
   - `repo` - Full repository access
   - `read:org` - Read organization membership
   - `workflow` - Update GitHub Action workflows (if needed)

### Environment Variable Setup
Add to your shell profile (`.bashrc`, `.zshrc`, etc.) or project `.envrc`:
```bash
export GITHUB_PERSONAL_ACCESS_TOKEN="your-token-here"
```

Or for project-specific setup in `.envrc`:
```bash
# Add this to your project's .envrc file
export GITHUB_PERSONAL_ACCESS_TOKEN="your-token-here"
```

**Security Note**: Never commit tokens to version control. Use environment variables or secure secret management.

## How to Use

### Automatic Usage
The AI assistant will automatically use the Sequential Thinking tool when:
- Breaking down complex problems
- Debugging multi-step issues
- Planning implementations
- Analyzing problems where the scope isn't initially clear

The GitHub tool will be used when:
- Reading repository files and structure
- Creating or updating issues
- Managing pull requests
- Automating repository workflows

### Manual Requests
You can also explicitly request structured thinking:
```
"Let's think through this step by step"
"Can you break this down systematically?"
"I want to approach this problem methodically"
```

For GitHub operations:
```
"Create an issue for this bug"
"Show me the recent commits in this repository"
"Help me create a pull request for this feature"
```

## Example Usage Scenarios

### Repository Management
```
"Can you create a GitHub issue for the failing test suite 
with details about the React version conflicts we discovered?"
```

### Automated Workflows
```
"Help me set up a GitHub Action that runs our quality checks 
and automatically creates issues for any failures."
```

### Code Review Automation
```
"Review the recent commits in the main branch and create 
a summary of changes for the team standup."
```

### Debugging Build Issues
```
"I'm having issues with my Release build showing a black screen. 
The JavaScript bundle is there but Expo Updates seems disabled. 
Help me debug this systematically."
```

### Planning Complex Features
```
"I need to implement visual regression testing for my app. 
This involves screenshot capture, baseline management, and comparison logic. 
Can you help me plan this step by step?"
```

### Architecture Decisions
```
"I'm trying to decide between different state management approaches 
for my React Native app. Can you help me think through the pros 
and cons systematically?"
```

## Adding New MCP Servers

To add new MCP servers:

1. Add the server configuration to `mcp.json`
2. Update this README with details about the new server
3. Run the setup script to propagate changes to projects

## Troubleshooting

If MCP servers aren't working:

1. Check that Node.js is installed (required for npx commands)
2. Verify the configuration in `mcp.json` is valid JSON
3. For GitHub server: Ensure `GITHUB_PERSONAL_ACCESS_TOKEN` is set
4. Restart Cursor IDE after making changes
5. Check the Cursor console for any error messages 