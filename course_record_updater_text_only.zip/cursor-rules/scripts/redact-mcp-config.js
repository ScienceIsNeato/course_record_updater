#!/usr/bin/env node

/**
 * Redact MCP Configuration Script
 * 
 * This script copies cursor-rules/.cursor/mcp.json to cursor-rules/.cursor/mcp.json.REDACTED
 * while replacing actual secrets with placeholder text for safe version control.
 */

const fs = require('fs');
const path = require('path');

const MCP_CONFIG_PATH = path.join(__dirname, '../.cursor/mcp.json');
const REDACTED_CONFIG_PATH = path.join(__dirname, '../.cursor/mcp.json.REDACTED');

// Token patterns to redact
const REDACTION_PATTERNS = [
  {
    pattern: /ghp_[a-zA-Z0-9_]{36}/g,
    replacement: 'YOUR_GITHUB_TOKEN_HERE'
  },
  {
    pattern: /gho_[a-zA-Z0-9_]{36}/g,
    replacement: 'YOUR_GITHUB_ORG_TOKEN_HERE'
  },
  {
    pattern: /ghu_[a-zA-Z0-9_]{36}/g,
    replacement: 'YOUR_GITHUB_USER_TOKEN_HERE'
  },
  // Add more patterns as needed for other services
];

function redactSecrets(content) {
  let redacted = content;
  
  REDACTION_PATTERNS.forEach(({ pattern, replacement }) => {
    redacted = redacted.replace(pattern, replacement);
  });
  
  return redacted;
}

function main() {
  try {
    // Check if source file exists
    if (!fs.existsSync(MCP_CONFIG_PATH)) {
      console.error(`❌ Source file not found: ${MCP_CONFIG_PATH}`);
      process.exit(1);
    }

    // Read the original config
    const originalContent = fs.readFileSync(MCP_CONFIG_PATH, 'utf8');
    
    // Validate JSON
    try {
      JSON.parse(originalContent);
    } catch (e) {
      console.error(`❌ Invalid JSON in ${MCP_CONFIG_PATH}: ${e.message}`);
      process.exit(1);
    }

    // Redact secrets
    const redactedContent = redactSecrets(originalContent);
    
    // Validate redacted JSON
    try {
      JSON.parse(redactedContent);
    } catch (e) {
      console.error(`❌ Invalid JSON after redaction: ${e.message}`);
      process.exit(1);
    }

    // Write the redacted version
    fs.writeFileSync(REDACTED_CONFIG_PATH, redactedContent, 'utf8');
    
    console.log(`✅ Successfully created redacted config: ${REDACTED_CONFIG_PATH}`);
    
    // Check if there were any differences
    if (originalContent === redactedContent) {
      console.log(`⚠️  Warning: No secrets found to redact`);
    } else {
      console.log(`🔒 Secrets successfully redacted`);
    }
    
  } catch (error) {
    console.error(`❌ Error: ${error.message}`);
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = { redactSecrets, REDACTION_PATTERNS }; 