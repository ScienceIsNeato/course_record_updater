# Cursor AI Rules

This repository contains AI interaction rules for Cursor IDE and related tools (Cline, Roo). The rules are organized to work with Cursor's new directory-based system while maintaining compatibility with Cline and Roo.

## Installation

### Using the Setup Script

1. Clone this repository to a permanent location:
   ```bash
   git clone git@github.com:ScienceIsNeato/cursor-rules.git ~/Documents/SourceCode/cursor-rules
   ```

2. Navigate to your project root and run the setup script:
   ```bash
   ~/Documents/SourceCode/cursor-rules/setup.sh
   ```

This will:
- Create a symlink from `.cursorrules` to the rules directory
- Add `.cursorrules` to your project's .gitignore


## Directory Structure

```
.
├── .cursor/
│   └── rules/
│       ├── main.mdc                    # Main configuration
│       ├── core_principles.mdc         # Core principles and practices
│       ├── development_workflow.mdc    # Development and testing workflow
│       ├── session_context.mdc         # AI session context management
│       ├── path_management.mdc         # Path and file operations
│       ├── response_format.mdc         # Response formatting rules
│       ├── issue_reporting.mdc         # Issue handling
│       ├── testing.mdc                 # Testing protocols
│       ├── third_party_tools.mdc       # Third-party tool integrations
│       └── projects/
│           ├── ganglia.mdc             # GANGLIA project rules
│           ├── fogofdog_frontend.mdc   # FogOfDog frontend rules
│           └── apertus_task_guidelines.mdc  # Comprehensive Apertus task guidelines
├── scripts/
│   ├── gcal_utils.py                   # Google Calendar integration
│   ├── jira_utils.py                  # JIRA integration
│   ├── md_to_pdf.py                   # Markdown to PDF conversion
│   ├── redact-mcp-config.js           # MCP config redaction
│   ├── requirements.txt               # Python dependencies
│   └── setup.py                       # Package setup
├── build_combined_cursorrules.sh      # Script to build .cursorrules
├── .cursorrules                       # Consolidated rules for Cline/Roo
├── setup.sh                           # Installation script
└── README.md
```

## 🚨 CRITICAL: Editing Rule Files Correctly

**ALWAYS edit files in the `cursor-rules/` directory (tracked), NEVER in `.cursor/rules/` (symlinked copy):**

**✅ CORRECT:**
```bash
# Edit the tracked source file
edit cursor-rules/.cursor/rules/development_workflow.mdc
```

**❌ WRONG:**
```bash
# Don't edit the symlinked copy - changes will be lost!
edit .cursor/rules/development_workflow.mdc
```

**Why this matters:**
- `.cursor/rules/` contains symlinks to the actual rule files
- The actual rule files are in `cursor-rules/.cursor/rules/` (tracked by git)
- Editing symlinked copies means changes aren't saved to the repository
- Always edit the source files in the `cursor-rules/` directory

## Rule Types

### Core Rules (.cursor/rules/*.mdc)
- **main.mdc**: Core configuration and module loading
- **core_principles.mdc**: Fundamental principles for AI interactions
- **development_workflow.mdc**: Development practices and testing workflow
- **session_context.mdc**: Guidelines for maintaining AI session context
- **path_management.mdc**: Rules for path and file operations
- **response_format.mdc**: Response formatting guidelines
- **issue_reporting.mdc**: Guidelines for issue reporting and tracking
- **testing.mdc**: Testing protocols and practices

### Project-Specific Rules (.cursor/rules/projects/*.mdc)
- **ganglia.mdc**: Rules specific to GANGLIA project
- **fogofdog_frontend.mdc**: Rules specific to FogOfDog frontend
- **apertus_task_guidelines.mdc**: Comprehensive guidelines for Apertus task creation

### Compatibility Rules (.cursorrules)
- Consolidated ruleset for Cline and Roo compatibility
- Contains essential rules from all .mdc files
- Automatically loaded by Cline and Roo extensions
- Built automatically by build_combined_cursorrules.sh

### Utility Scripts (scripts/)
- **gcal_utils.py**: Google Calendar integration for event management
- **jira_utils.py**: JIRA integration for issue and epic creation
- **md_to_pdf.py**: Markdown to PDF conversion with professional styling
- **redact-mcp-config.js**: MCP configuration security redaction
- **requirements.txt**: Python dependencies for all scripts
- **setup.py**: Package setup for script installation

## Usage

### Cursor IDE
1. Place the `.cursor` directory in your project root
2. Cursor will automatically load rules from `.cursor/rules/*.mdc`
3. Rules are applied based on their glob patterns

### Cline/Roo (VS Code)
1. Place `.cursorrules` in your project root
2. Cline and Roo will automatically load these rules
3. No additional configuration needed

## Rule File Format

### .mdc Files
```yaml
---
Description: Brief description of the rules
Globs: "glob pattern"  # Files these rules apply to
---

# Rule Section

## Subsection
- Rule 1
- Rule 2
```

### .cursorrules
- Plain text/Markdown format
- Contains consolidated rules from all .mdc files
- No YAML frontmatter needed
- Automatically applied to all files
- Automatically built by build script

## Contributing

1. Add new rules in appropriate .mdc files
2. Run build_combined_cursorrules.sh to update .cursorrules
3. Follow existing formatting conventions
4. Test rules in both Cursor IDE and VS Code

## Updating

To update the rules in your project:

1. Navigate to your cursor-rules installation
2. Pull the latest changes:
   ```bash
   cd ~/Documents/SourceCode/cursor-rules
   git pull
   ```

The changes will automatically be reflected in all projects using the symlink.

## Viewing Rule Metadata

To view the metadata (description, globs, etc.) of any MDC file, you can use this command:
```bash
sed -n '/^---$/,/^---$/p' path/to/file.mdc
```

To view metadata for all MDC files:
```bash
for f in .cursor/rules/*.mdc .cursor/rules/projects/*.mdc; do 
  echo -e "\n=== $f ==="; 
  sed -n '/^---$/,/^---$/p' "$f"; 
done
```

## License

MIT License

# Cursor Rules and MCP Configuration

This directory contains Cursor IDE rules and Model Context Protocol (MCP) server configurations.

## MCP Configuration Security

### Files Structure

- **`.cursor/mcp.json`** - The actual MCP configuration with real secrets (Git ignored)
- **`.cursor/mcp.json.REDACTED`** - Template version with placeholder secrets (Version controlled)
- **`scripts/redact-mcp-config.js`** - Utility script for redacting secrets
- **`.githooks/pre-commit`** - Git hook ensuring redacted config stays in sync

### Why Two Files?

The MCP configuration contains sensitive API tokens and secrets that should never be committed to version control. However, we also want to:

1. **Share the configuration structure** with team members
2. **Track changes** to the MCP server setup
3. **Provide a template** for new developers
4. **Prevent accidental secret commits**

### Setup for New Developers

1. **Copy the template:**
   ```bash
   cp .cursor/mcp.json.REDACTED .cursor/mcp.json
   ```

2. **Replace placeholders** with your actual tokens:
   ```json
   {
     "env": {
       "GITHUB_PERSONAL_ACCESS_TOKEN": "ghp_your_actual_token_here"
     }
   }
   ```

3. **Install git hooks** (optional but recommended):
   ```bash
   chmod +x .githooks/pre-commit
   git config core.hooksPath .githooks
   ```

### Updating Configuration

When you modify `.cursor/mcp.json`, run the redaction script to update the template:

```bash
node scripts/redact-mcp-config.js
git add .cursor/mcp.json.REDACTED
```

The git pre-commit hook will automatically check this for you and prevent commits if the redacted version is out of sync.

### Security Features

- **🔒 Real secrets never committed** - `.cursor/mcp.json` is git-ignored
- **📝 Template tracked** - `.cursor/mcp.json.REDACTED` shows structure without secrets
- **🛡️ Auto-protection** - Git hooks prevent out-of-sync commits
- **🔍 Token detection** - Script automatically detects and redacts GitHub tokens

### Token Patterns Supported

The redaction script automatically detects and replaces:

- `ghp_*` - GitHub personal access tokens
- `gho_*` - GitHub organization tokens  
- `ghu_*` - GitHub user tokens

Additional patterns can be added to `scripts/redact-mcp-config.js` as needed.

### Troubleshooting

**"No secrets found to redact"** - Your `.cursor/mcp.json` might already contain placeholder values

**Git hook fails** - Run `node scripts/redact-mcp-config.js` manually and stage the changes

**MCP servers not starting** - Check Cursor's Developer Console (`Cmd+Option+I`) for errors
