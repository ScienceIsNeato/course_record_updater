"""
Bulk Email Models package for Course Record Updater.
"""

from bulk_email_models.bulk_email_job import BulkEmailJob

__all__ = ["BulkEmailJob"]

