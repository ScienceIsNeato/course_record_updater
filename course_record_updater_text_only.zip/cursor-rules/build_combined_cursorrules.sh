#!/bin/bash

# Ensure we're running from this repo's root directory
cd "$(dirname "$0")" || exit 1

# Get the parent directory name for project matching
PARENT_DIR_NAME=$(basename "$(dirname "$(pwd)")")
echo "Parent directory: $PARENT_DIR_NAME"

# Create the output file in the parent directory
PARENT_DIR="$(dirname "$(pwd)")"
OUTPUT_FILE="$PARENT_DIR/.cursorrules"

# Start with a clean .cursorrules file
echo "# Cursor AI Rules" > "$OUTPUT_FILE"
echo "" >> "$OUTPUT_FILE"

# Function to process a file
process_file() {
    local file=$1
    local filename=$(basename "$file")
    local in_frontmatter=0
    local frontmatter_count=0
    local previous_line=""
    local content=""
    
    # Add filename as top-level header
    echo "# ${filename}" >> "$OUTPUT_FILE"
    echo "" >> "$OUTPUT_FILE"
    
    while IFS= read -r line; do
        # Handle YAML frontmatter
        if [[ $line == "---" ]]; then
            ((frontmatter_count++))
            if [[ $frontmatter_count == 2 ]]; then
                in_frontmatter=0
            else
                in_frontmatter=1
            fi
            continue
        fi
        
        # Skip frontmatter content, Description/Globs lines
        if [[ $in_frontmatter == 0 && ! $line =~ "Description:" && ! $line =~ "Globs:" ]]; then
            # Only add line if it's not empty or previous line wasn't empty
            if [[ -n $line ]] || [[ -n $previous_line ]]; then
                content+="$line"$'\n'
            fi
            previous_line="$line"
        fi
    done < "$file"
    
    # Trim trailing newlines and add exactly one newline at the end
    content=$(echo "$content" | sed -e :a -e '/^\n*$/{$d;N;ba' -e '}')
    echo "$content" >> "$OUTPUT_FILE"
    echo "" >> "$OUTPUT_FILE"
}

# Process core rules first
echo "## Core Rules" >> "$OUTPUT_FILE"
echo "" >> "$OUTPUT_FILE"

# First process main.mdc if it exists
if [[ -f ".cursor/rules/main.mdc" ]]; then
    process_file ".cursor/rules/main.mdc"
fi

# Then process other core rules
for file in .cursor/rules/*.mdc; do
    if [[ -f "$file" && ! "$file" =~ "projects/" && $(basename "$file") != "main.mdc" ]]; then
        process_file "$file"
    fi
done

# Process project-specific rules that match the parent directory
echo "## Project Rules" >> "$OUTPUT_FILE"
echo "" >> "$OUTPUT_FILE"

# Function to check if a file matches the parent directory
matches_parent_dir() {
    local file=$1
    local basename=$(basename "$file" .mdc)
    local parent_dir_lower=$(echo "$PARENT_DIR_NAME" | tr '[:upper:]' '[:lower:]')
    local basename_lower=$(echo "$basename" | tr '[:upper:]' '[:lower:]')
    
    # Check if the parent directory name is contained in the basename (case insensitive)
    if [[ "$basename_lower" == *"$parent_dir_lower"* || "$parent_dir_lower" == *"$basename_lower"* ]]; then
        return 0  # Match found
    else
        return 1  # No match
    fi
}

# Process project files that match the parent directory
echo "# Including project files matching: $PARENT_DIR_NAME" >> "$OUTPUT_FILE"
echo "" >> "$OUTPUT_FILE"

matched_files=0
for file in .cursor/rules/projects/*.mdc; do
    if [[ -f "$file" ]]; then
        if matches_parent_dir "$file"; then
            echo "Including project file: $(basename "$file")" >> "$OUTPUT_FILE"
            process_file "$file"
            ((matched_files++))
        fi
    fi
done

if [[ $matched_files -eq 0 ]]; then
    echo "No matching project files found for: $PARENT_DIR_NAME" >> "$OUTPUT_FILE"
    echo "" >> "$OUTPUT_FILE"
fi

# Remove any trailing newlines at the end of the file
sed -i '' -e :a -e '/^\n*$/{$d;N;ba' -e '}' "$OUTPUT_FILE"

echo "Combined .cursorrules file generated successfully in parent directory"