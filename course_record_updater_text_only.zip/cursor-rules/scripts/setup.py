from setuptools import find_packages, setup

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

with open("requirements.txt", "r", encoding="utf-8") as f:
    requirements = f.read().splitlines()

setup(
    name="cursor-utility-scripts",
    version="0.1.0",
    author="Cursor AI User & Agent",
    description="A collection of utility scripts for common tasks and third-party service interactions.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="#",  # Replace with actual URL if these scripts are hosted
    packages=find_packages(),
    install_requires=requirements,
    python_requires=">=3.8",  # Specify your minimum Python version
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",  # Assuming MIT, adjust if different
        "Operating System :: OS Independent",
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Utilities",
    ],
    # If you want to create command-line executables, you can define entry points here
    # For example:
    # entry_points={
    #     'console_scripts': [
    #         'gcal=gcal_utils:main', # Assumes gcal_utils.py has a main() function
    #         'jutil=jira_utils:main', # Assumes jira_utils.py has a main() function
    #     ],
    # },
)
