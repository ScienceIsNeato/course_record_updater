# Utility Scripts

This directory contains a collection of Python utility scripts designed for interacting with various third-party services and assisting with common tasks.

## Included Scripts:

*   `gcal_utils.py`: Provides functionality for interacting with the Google Calendar API, such as adding and updating events. This script requires Google Application Default Credentials (ADC) and dependencies listed in `requirements.txt`.
*   `jira_utils.py`: Provides functionality for interacting with the Jira API, such as creating epics and tasks, and updating issues. This script requires Jira API credentials set as environment variables and dependencies listed in `requirements.txt`.

## Installation:

These scripts are part of the `cursor-utility-scripts` package. To set up the required Python environment and install dependencies, run the main setup script from the workspace root:

```bash
./cursor-rules/setup.sh
```

This script will create a Python virtual environment (`.venv`) within the `cursor-rules/scripts/` directory and install the necessary packages.

## Dependencies:

The required Python packages are listed in `requirements.txt`:

*   `google-api-python-client`
*   `google-auth-httplib2`
*   `google-auth-oauthlib`
*   `jira`

## Usage:

To use the scripts, activate the virtual environment or explicitly call the Python interpreter from the virtual environment. The virtual environment is located at `${AGENT_HOME}/cursor-rules/scripts/.venv`.

Example usage (assuming you are in the workspace root directory and `AGENT_HOME` is set):

```bash
# Example using gcal_utils.py
${AGENT_HOME}/cursor-rules/scripts/.venv/bin/python ${AGENT_HOME}/cursor-rules/scripts/gcal_utils.py add --summary "My Event" --start_time "YYYY-MM-DDTHH:MM:SS" --end_time "YYYY-MM-DDTHH:MM:SS"

# Example using jira_utils.py
${AGENT_HOME}/cursor-rules/scripts/.venv/bin/python ${AGENT_HOME}/cursor-rules/scripts/jira_utils.py --action create_task --epic-name "My Epic" --summary "My Task" --description "Task details."
```

Ensure required credentials (Google ADC for gcal_utils, Jira env vars for jira_utils) are set up before running the scripts. 