"""
Third-party integration tests

Tests that verify integration with external services (Ethereal Email, etc.)
These tests require network access and external service credentials.
"""
