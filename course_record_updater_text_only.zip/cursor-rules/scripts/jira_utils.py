import argparse
import json
import os

from jira import JIRA


# --- Connection ---
def connect_jira(server_url, username, api_token):
    """Connects to the Jira instance using API token authentication."""
    try:
        jira_options = {"server": server_url}
        jira = JIRA(options=jira_options, basic_auth=(username, api_token))
        print("Successfully connected to Jira.")
        return jira
    except Exception as e:
        print(f"Failed to connect to Jira: {e}")
        return None


# --- Epic Key Storage ---
EPIC_KEYS_FILE = "data/epic_keys.json"


def load_epic_keys():
    """Loads the epic name-to-key mapping from the JSON file."""
    if not os.path.exists(EPIC_KEYS_FILE):
        return {}
    try:
        with open(EPIC_KEYS_FILE, "r") as f:
            return json.load(f)
    except json.JSONDecodeError:
        print(
            f"Warning: Could not decode JSON from {EPIC_KEYS_FILE}. Returning empty map."
        )
        return {}
    except Exception as e:
        print(f"Warning: Error loading {EPIC_KEYS_FILE}: {e}. Returning empty map.")
        return {}


def save_epic_keys(keys_dict):
    """Saves the epic name-to-key mapping to the JSON file."""
    try:
        # Ensure the data directory exists
        os.makedirs(os.path.dirname(EPIC_KEYS_FILE), exist_ok=True)
        with open(EPIC_KEYS_FILE, "w") as f:
            json.dump(keys_dict, f, indent=2)
        # print(f"Successfully saved epic keys to {EPIC_KEYS_FILE}")
    except Exception as e:
        print(f"Error saving epic keys to {EPIC_KEYS_FILE}: {e}")


def get_epic_key_by_name(epic_name):
    """Retrieves the epic key for a given epic name from the storage."""
    keys = load_epic_keys()
    key = keys.get(epic_name)
    if not key:
        print(f"Error: Epic key for name '{epic_name}' not found in {EPIC_KEYS_FILE}.")
    return key


# --- Epic Creation ---
def create_epic(jira_conn, project_key, epic_name, summary, description=""):
    """Creates a new Epic in the specified Jira project."""
    if not jira_conn:
        print("Jira connection not established. Cannot create epic.")
        return None

    issue_dict = {
        'project': {'key': project_key},
        'summary': summary,
        'description': description.replace('%%NL%%', '\n'),
        'issuetype': {'name': 'Epic'},
    }

    try:
        new_epic = jira_conn.create_issue(fields=issue_dict)
        print(f"Successfully created Epic: {new_epic.key} - {epic_name}")
        # Save the new epic key
        try:
            keys = load_epic_keys()
            keys[epic_name] = new_epic.key  # Use epic_name as the key in the dictionary
            save_epic_keys(keys)
        except Exception as save_e:
            print(f"Warning: Could not save epic key for '{epic_name}': {save_e}")
        return new_epic
    except Exception as e:
        print(f"Failed to create Epic: {e}")
        return None


# --- Task Creation ---
def create_task_in_epic(
    jira_conn, project_key, epic_name, summary, description="", issue_type="Task"
):
    """Creates a new issue and links it to the specified Epic by name."""
    if not jira_conn:
        print("Jira connection not established. Cannot create task.")
        return None

    # Get the actual epic key from the stored mapping
    epic_key = get_epic_key_by_name(epic_name)
    if not epic_key:
        # Error message already printed by get_epic_key_by_name
        return None

    issue_dict = {
        'project': {'key': project_key},
        'summary': summary,
        'description': description.replace('%%NL%%', '\n'),
        'issuetype': {'name': issue_type},
        'parent': {'key': epic_key}, # Link using the standard Parent field
    }

    try:
        new_task = jira_conn.create_issue(fields=issue_dict)
        print(
            f"Successfully created Task '{new_task.key}' in Epic '{epic_name} ({epic_key})'"
        )
        return new_task
    except Exception as e:
        print(f"Failed to create Task in Epic '{epic_name}': {e}")
        return None


# --- Issue Update ---
def update_issue(jira_conn, issue_key, fields_to_update):
    """Updates specific fields of an existing Jira issue."""
    if not jira_conn:
        print("Jira connection not established. Cannot update issue.")
        return False

    try:
        issue = jira_conn.issue(issue_key)
        if 'description' in fields_to_update:
            description = fields_to_update['description']
            fields_to_update['description'] = description.replace('%%NL%%', '\n')
        issue.update(fields=fields_to_update)
        print(f"Successfully updated issue {issue_key}.")
        return True
    except Exception as e:
        print(f"Failed to update issue {issue_key}: {e}")
        return False


# --- Main Execution ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Create or Update a single Jira Epic or Task."
    )
    parser.add_argument(
        "--action",
        required=True,
        choices=["create_epic", "create_task", "update_issue"],
        help="Action to perform.",
    )
    # Arguments for create_epic / create_task
    parser.add_argument(
        "--summary", help="Summary for the new issue (required for create_*)."
    )
    parser.add_argument(
        "--description", default="", help="Description for the new/updated issue."
    )
    parser.add_argument(
        "--epic-name", help="Name of the parent epic (required for create_task)."
    )
    parser.add_argument(
        "--issue-type",
        default="Task",
        help="Issue type for create_task (default: Task).",
    )
    parser.add_argument(
        "--epic-actual-name",
        help="Specific Epic Name field value for create_epic (defaults to summary).",
    )
    # Arguments for update_issue
    parser.add_argument(
        "--issue-key", help="Key of the issue to update (required for update_issue)."
    )
    # Note: For updates, we'll pass fields as JSON string for simplicity, e.g., --fields '{"description": "New text"}'
    parser.add_argument(
        "--fields", help="JSON string of fields to update for update_issue."
    )

    args = parser.parse_args()

    # Load credentials securely
    server = os.environ.get("JIRA_SERVER", "https://scienmockusneato.atlassian.net")
    user = os.environ.get("JIRA_USERNAME")
    token = os.environ.get("JIRA_API_TOKEN")
    project = "MARTIN"  # Assuming constant project

    if not all([server, user, token, project]):
        print(
            "Error: Please configure JIRA_SERVER, JIRA_USERNAME, JIRA_API_TOKEN environment variables."
        )
        exit(1)

    print(f"Connecting to Jira server: {server} as user: {user} for project: {project}")
    jira_connection = connect_jira(server, user, token)

    if jira_connection:
        if args.action == "create_epic":
            epic_actual_name = (
                args.epic_actual_name if args.epic_actual_name else args.summary
            )
            print(
                f"Attempting to create Epic: '{args.summary}' (Epic Name: '{epic_actual_name}')"
            )
            create_epic(
                jira_connection,
                project_key=project,
                epic_name=epic_actual_name,  # This is the specific Epic Name field
                summary=args.summary,
                description=args.description,
            )

        elif args.action == "create_task":
            if not args.epic_name:
                print("Error: --epic-name is required for create_task action.")
                exit(1)
            print(
                f"Attempting to create Task: '{args.summary}' under Epic '{args.epic_name}'"
            )
            create_task_in_epic(
                jira_connection,
                project_key=project,
                epic_name=args.epic_name,  # The name of the parent epic to link to
                summary=args.summary,
                description=args.description,
                issue_type=args.issue_type,
            )

        elif args.action == "update_issue":
            if not args.issue_key or not args.fields:
                print(
                    "Error: --issue-key and --fields (as JSON string) are required for update_issue action."
                )
                exit(1)
            try:
                fields_to_update = json.loads(args.fields)
                if args.description: # Allow overriding description via separate arg too
                  fields_to_update['description'] = args.description.replace('%%NL%%', '\n')
            except json.JSONDecodeError:
                print("Error: --fields argument must be a valid JSON string.")
                exit(1)
            print(f"Attempting to update Issue: {args.issue_key}")
            update_issue(
                jira_connection,
                issue_key=args.issue_key,
                fields_to_update=fields_to_update,
            )

    else:
        print("Could not connect to Jira. Aborting.")
        exit(1)
