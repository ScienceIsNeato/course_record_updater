#!/usr/bin/env python3
"""
Markdown to PDF Converter

Converts markdown files to PDF format using HTML as an intermediate step.
Supports Chrome/Chromium headless mode for high-quality PDF generation.

Usage:
    python md_to_pdf.py input.md [output.pdf]
    
If output filename is not provided, it will use the input filename with .pdf extension.
"""

import argparse
import os
import subprocess
import sys
from pathlib import Path

import markdown


def convert_md_to_html(md_file, html_file):
    """Convert markdown to HTML with professional styling"""
    
    # Read the markdown file
    with open(md_file, 'r', encoding='utf-8') as f:
        md_content = f.read()
    
    # Convert markdown to HTML with extensions
    html = markdown.markdown(md_content, extensions=['tables', 'fenced_code', 'toc'])
    
    # Add professional CSS styling
    html_with_style = f'''<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{Path(md_file).stem}</title>
    <style>
        @page {{
            margin: 0.75in;
            size: letter;
        }}
        body {{ 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6; 
            font-size: 11px;
            color: #333;
            max-width: none;
        }}
        h1 {{ 
            color: #2c3e50; 
            border-bottom: 3px solid #3498db; 
            padding-bottom: 10px; 
            font-size: 22px;
            margin-top: 0;
            page-break-after: avoid;
        }}
        h2 {{ 
            color: #34495e; 
            margin-top: 25px; 
            margin-bottom: 15px;
            font-size: 16px;
            background-color: #f8f9fa;
            padding: 8px 12px;
            border-left: 4px solid #3498db;
            page-break-after: avoid;
        }}
        h3 {{ 
            color: #2980b9; 
            margin-top: 20px; 
            margin-bottom: 10px;
            font-size: 13px;
            page-break-after: avoid;
        }}
        ul {{ 
            margin: 8px 0; 
            padding-left: 20px;
        }}
        li {{ 
            margin: 2px 0; 
            line-height: 1.4;
        }}
        strong {{ 
            color: #2c3e50; 
            font-weight: 600;
        }}
        hr {{ 
            border: none;
            border-top: 2px solid #bdc3c7; 
            margin: 25px 0; 
            page-break-after: avoid;
        }}
        p {{ 
            margin: 6px 0; 
            line-height: 1.5;
        }}
        code {{
            background-color: #f1f2f6;
            padding: 2px 4px;
            border-radius: 3px;
            font-family: 'SF Mono', Monaco, 'Cascadia Code', monospace;
            font-size: 10px;
        }}
        pre {{
            background-color: #f8f9fa;
            padding: 12px;
            border-radius: 5px;
            border-left: 4px solid #3498db;
            overflow-x: auto;
            font-size: 10px;
        }}
        table {{
            border-collapse: collapse;
            width: 100%;
            margin: 15px 0;
            font-size: 10px;
        }}
        th, td {{
            border: 1px solid #ddd;
            padding: 6px 8px;
            text-align: left;
        }}
        th {{
            background-color: #f2f2f2;
            font-weight: 600;
        }}
        .warning {{
            color: #e74c3c;
            font-weight: 500;
        }}
        .verification-note {{
            font-style: italic;
            color: #7f8c8d;
            font-size: 10px;
        }}
        /* Print-specific styles */
        @media print {{
            body {{ font-size: 10px; }}
            h1 {{ font-size: 18px; }}
            h2 {{ font-size: 14px; }}
            h3 {{ font-size: 12px; }}
            .page-break {{ page-break-before: always; }}
            .no-break {{ page-break-inside: avoid; }}
        }}
    </style>
</head>
<body>
{html}
</body>
</html>'''
    
    # Save HTML file
    with open(html_file, 'w', encoding='utf-8') as f:
        f.write(html_with_style)
    
    print(f"✓ HTML file created: {html_file}")
    return True

def html_to_pdf_chrome(html_file, pdf_file):
    """Convert HTML to PDF using Chrome/Chromium headless"""
    try:
        # Try different Chrome/Chromium executable paths
        chrome_commands = [
            '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',  # macOS
            '/Applications/Chromium.app/Contents/MacOS/Chromium',           # macOS Chromium
            'google-chrome',                                                # Linux
            'chromium-browser',                                             # Linux
            'chromium',                                                     # Linux
            r'C:\Program Files\Google\Chrome\Application\chrome.exe',      # Windows
            r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe' # Windows 32-bit
        ]
        
        for chrome_cmd in chrome_commands:
            try:
                # Convert to absolute paths
                html_path = Path(html_file).resolve()
                pdf_path = Path(pdf_file).resolve()
                
                cmd = [
                    chrome_cmd,
                    '--headless',
                    '--disable-gpu',
                    '--disable-software-rasterizer',
                    '--disable-dev-shm-usage',
                    '--no-sandbox',
                    f'--print-to-pdf={pdf_path}',
                    '--print-to-pdf-no-header',
                    '--run-all-compositor-stages-before-draw',
                    '--virtual-time-budget=5000',
                    f'file://{html_path}'
                ]
                
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                if result.returncode == 0 and pdf_path.exists():
                    print(f"✓ PDF created successfully: {pdf_file}")
                    return True
                elif result.stderr:
                    print(f"Chrome error: {result.stderr}")
                    
            except (FileNotFoundError, subprocess.TimeoutExpired):
                continue
                
        return False
        
    except Exception as e:
        print(f"Chrome conversion failed: {e}")
        return False

def main():
    parser = argparse.ArgumentParser(
        description='Convert Markdown files to PDF',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  python md_to_pdf.py document.md
  python md_to_pdf.py document.md output.pdf
  python md_to_pdf.py ../LOCAL_SPECIALISTS_OPTIONS_COLLATED.md
        '''
    )
    
    parser.add_argument('input_file', help='Input markdown file')
    parser.add_argument('output_file', nargs='?', help='Output PDF file (optional)')
    parser.add_argument('--keep-html', action='store_true', help='Keep intermediate HTML file')
    parser.add_argument('--html-only', action='store_true', help='Generate HTML only, skip PDF')
    
    args = parser.parse_args()
    
    # Resolve input file path
    input_path = Path(args.input_file)
    if not input_path.exists():
        print(f"Error: Input file '{args.input_file}' not found")
        sys.exit(1)
    
    # Determine output file path
    if args.output_file:
        output_path = Path(args.output_file)
    else:
        output_path = input_path.with_suffix('.pdf')
    
    # Create temporary HTML file
    html_path = input_path.with_suffix('.temp.html')
    
    try:
        # Convert MD to HTML
        print(f"Converting {input_path.name} to HTML...")
        if not convert_md_to_html(input_path, html_path):
            print("Failed to convert markdown to HTML")
            sys.exit(1)
        
        if args.html_only:
            # Just rename HTML file and exit
            final_html = input_path.with_suffix('.html')
            html_path.rename(final_html)
            print(f"✓ HTML file saved as: {final_html}")
            return
        
        # Convert HTML to PDF
        print(f"Converting HTML to PDF...")
        if html_to_pdf_chrome(html_path, output_path):
            print(f"✓ Conversion completed successfully!")
            print(f"  Output: {output_path}")
        else:
            print("❌ PDF conversion failed. Chrome/Chromium not found.")
            print(f"HTML file available at: {html_path}")
            print("\nManual conversion options:")
            print("1. Open the HTML file in your browser")
            print("2. Press Ctrl+P (or Cmd+P on Mac)")
            print("3. Choose 'Save as PDF' as destination")
            print("4. Adjust print settings as needed")
            return
            
    finally:
        # Clean up temporary HTML file unless requested to keep it
        if html_path.exists() and not args.keep_html and not args.html_only:
            html_path.unlink()

if __name__ == "__main__":
    main() 