#!/bin/bash

# Cursor Rules Setup Script
# This script creates symlinks to the cursor rules, updates .gitignore, and builds the combined rules file

# Get the absolute path of the cursorrules directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PARENT_DIR="$(dirname "$SCRIPT_DIR")" # This is the project root where .cursorrules symlink will be
CURSOR_RULES_SCRIPTS_DIR="$SCRIPT_DIR/scripts" # Path to the scripts directory within cursor-rules

# Make build script executable
chmod +x "$SCRIPT_DIR/build_combined_cursorrules.sh"

# Check if .cursor exists and is not a symlink in the parent directory (project root)
if [ -e "$PARENT_DIR/.cursor" ] && [ ! -L "$PARENT_DIR/.cursor" ]; then
    echo "⚠️  Warning: $PARENT_DIR/.cursor exists and is not a symlink."
    echo "Please remove it first if you want to create a new symlink."
    exit 1
fi

# Remove existing symlinks if they exist in the parent directory (project root)
if [ -L "$PARENT_DIR/.cursorrules" ]; then
    rm "$PARENT_DIR/.cursorrules"
    echo "🗑️  Removed existing .cursorrules symlink from $PARENT_DIR"
fi

if [ -e "$PARENT_DIR/.cursorrules" ] && [ ! -L "$PARENT_DIR/.cursorrules" ]; then
    rm "$PARENT_DIR/.cursorrules"
    echo "🗑️  Removed existing .cursorrules file from $PARENT_DIR"
fi

if [ -L "$PARENT_DIR/.cursor" ]; then
    rm "$PARENT_DIR/.cursor"
    echo "🗑️  Removed existing .cursor symlink from $PARENT_DIR"
fi

# Create symlink to .cursor directory in the parent directory (project root)
ln -s "$SCRIPT_DIR/.cursor" "$PARENT_DIR/.cursor"
echo "🔗 Created .cursor symlink in $PARENT_DIR"

# Copy MCP configuration if it exists and is not already present
if [ -f "$SCRIPT_DIR/.cursor/mcp.json" ]; then
    if [ ! -f "$PARENT_DIR/.cursor/mcp.json" ] || [ "$SCRIPT_DIR/.cursor/mcp.json" -nt "$PARENT_DIR/.cursor/mcp.json" ]; then
        # Since we're using symlink, the MCP configuration is automatically available
        echo "✅ MCP configuration available via symlink at $PARENT_DIR/.cursor/mcp.json"
    else
        echo "ℹ️  MCP configuration already up to date in $PARENT_DIR"
    fi
else
    echo "ℹ️  No MCP configuration found in cursor-rules"
fi

# Add to .gitignore in parent directory (project root) if not already present
if [ -f "$PARENT_DIR/.gitignore" ]; then
    if ! grep -q "^\.cursorrules$" "$PARENT_DIR/.gitignore"; then
        echo ".cursorrules" >> "$PARENT_DIR/.gitignore"
        echo "✅ Added .cursorrules to $PARENT_DIR/.gitignore"
    else
        echo "ℹ️  .cursorrules already in $PARENT_DIR/.gitignore"
    fi
    if ! grep -q "^\.cursor$" "$PARENT_DIR/.gitignore"; then
        echo ".cursor" >> "$PARENT_DIR/.gitignore"
        echo "✅ Added .cursor to $PARENT_DIR/.gitignore"
    else
        echo "ℹ️  .cursor already in $PARENT_DIR/.gitignore"
    fi
else
    echo ".cursorrules" > "$PARENT_DIR/.gitignore"
    echo ".cursor" >> "$PARENT_DIR/.gitignore"
    echo "✅ Created $PARENT_DIR/.gitignore with .cursorrules and .cursor"
fi

# Add AGENT_HOME to .envrc in parent directory (project root) if needed
AGENT_HOME_EXPORT="export AGENT_HOME=\\"$PARENT_DIR\\""

if [ -f "$PARENT_DIR/.envrc" ]; then
    if grep -q "export AGENT_HOME=" "$PARENT_DIR/.envrc"; then
        echo "ℹ️  AGENT_HOME already defined in $PARENT_DIR/.envrc"
    else
        echo "" >> "$PARENT_DIR/.envrc"
        echo "# Path Management for Cursor AI" >> "$PARENT_DIR/.envrc"
        echo "$AGENT_HOME_EXPORT" >> "$PARENT_DIR/.envrc"
        echo "✅ Added AGENT_HOME to existing $PARENT_DIR/.envrc file"
    fi
else
    echo "# Path Management for Cursor AI" > "$PARENT_DIR/.envrc"
    echo "$AGENT_HOME_EXPORT" >> "$PARENT_DIR/.envrc"
    echo "✅ Created new $PARENT_DIR/.envrc file with AGENT_HOME"
fi

# Run direnv allow in parent directory (project root) if direnv is installed
if command -v direnv &> /dev/null; then
    echo "🔄 Activating direnv for project: $PARENT_DIR"
    cd "$PARENT_DIR" && direnv allow
    # cd back to SCRIPT_DIR in case direnv messages interfere with subsequent cd
    cd "$SCRIPT_DIR" 
    echo "✅ Ran direnv allow to activate the project environment"
else
    echo "⚠️  direnv not found. Please install direnv and run 'direnv allow' in $PARENT_DIR."
fi

# Setup for utility scripts in cursor-rules/scripts/
echo ""
echo "🛠️  Setting up utility scripts environment in $CURSOR_RULES_SCRIPTS_DIR..."
if [ -d "$CURSOR_RULES_SCRIPTS_DIR" ]; then
    # Create a virtual environment if it doesn\'t exist
    if [ ! -d "$CURSOR_RULES_SCRIPTS_DIR/.venv" ]; then
        echo "🐍 Creating Python virtual environment in $CURSOR_RULES_SCRIPTS_DIR/.venv..."
        python3 -m venv "$CURSOR_RULES_SCRIPTS_DIR/.venv"
        if [ $? -ne 0 ]; then
            echo "❌ Failed to create virtual environment. Please check your Python3 installation."
            # Optionally exit here, or let it try to proceed
        fi
    else
        echo "🐍 Python virtual environment already exists at $CURSOR_RULES_SCRIPTS_DIR/.venv."
    fi

    # Activate virtual environment and install dependencies
    # Use a subshell to ensure activation is localized
    (
        echo "激活 Setting PATH to include scripts venv: $CURSOR_RULES_SCRIPTS_DIR/.venv/bin"
        # shellcheck source=/dev/null
        source "$CURSOR_RULES_SCRIPTS_DIR/.venv/bin/activate"
        
        if [ -f "$CURSOR_RULES_SCRIPTS_DIR/requirements.txt" ]; then
            echo "📦 Installing dependencies from $CURSOR_RULES_SCRIPTS_DIR/requirements.txt..."
            pip install -r "$CURSOR_RULES_SCRIPTS_DIR/requirements.txt"
            if [ $? -ne 0 ]; then
                echo "❌ Failed to install dependencies from requirements.txt."
            else
                echo "✅ Dependencies installed successfully."
            fi
        else
            echo "ℹ️  No requirements.txt found in $CURSOR_RULES_SCRIPTS_DIR. Skipping dependency installation."
        fi

        if [ -f "$CURSOR_RULES_SCRIPTS_DIR/setup.py" ]; then
            echo "⚙️  Running setup.py for utility scripts..."
            # Using pip install -e . makes the package available in editable mode
            pip install -e "$CURSOR_RULES_SCRIPTS_DIR"
            if [ $? -ne 0 ]; then
                echo "❌ Failed to run setup.py for scripts."
            else
                echo "✅ setup.py executed successfully."
            fi
        else
            echo "ℹ️  No setup.py found in $CURSOR_RULES_SCRIPTS_DIR. Skipping."
        fi
    )
    # Check if subshell operations were successful based on existence of key files/dirs if needed
    if [ ! -f "$CURSOR_RULES_SCRIPTS_DIR/.venv/bin/pip" ]; then
         echo "⚠️  Virtual environment setup for scripts might have issues. Check logs."
    fi
else
    echo "ℹ️  Scripts directory $CURSOR_RULES_SCRIPTS_DIR not found. Skipping utility scripts setup."
fi


# Build combined rules file (for the project where setup.sh is run)
echo ""
echo "🔄 Building combined .cursorrules file for the project: $PARENT_DIR..."
"$SCRIPT_DIR/build_combined_cursorrules.sh"

echo ""
echo "✅ Setup complete! Cursor rules symlinked, .gitignore updated, utility scripts environment configured, and .cursorrules file built for $PARENT_DIR."
echo "👉 If you use direnv, ensure it has reloaded the environment for $PARENT_DIR."
echo "👉 For utility scripts, you can typically run them using: $CURSOR_RULES_SCRIPTS_DIR/.venv/bin/python $CURSOR_RULES_SCRIPTS_DIR/your_script.py"
