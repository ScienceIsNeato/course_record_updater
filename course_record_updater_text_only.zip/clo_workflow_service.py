"""
CLO Workflow Service

Manages the submission, review, and approval workflow for Course Learning Outcomes (CLOs).
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from constants import CLOApprovalStatus, CLOStatus
from database_service import db
from email_service import EmailService
from logging_config import get_logger

logger = get_logger(__name__)


class CLOWorkflowService:
    """Service for managing CLO submission and approval workflows."""

    @staticmethod
    def submit_clo_for_approval(outcome_id: str, user_id: str) -> bool:
        """
        Submit a CLO for approval review.

        Args:
            outcome_id: The ID of the course outcome to submit
            user_id: The ID of the user submitting (instructor)

        Returns:
            bool: True if submission successful, False otherwise
        """
        try:
            outcome = db.get_course_outcome(outcome_id)
            if not outcome:
                logger.error(f"CLO not found: {outcome_id}")
                return False

            # Update status and submission metadata
            update_data = {
                "status": CLOStatus.AWAITING_APPROVAL,
                "submitted_at": datetime.utcnow(),
                "submitted_by_user_id": user_id,
                "approval_status": CLOApprovalStatus.PENDING,
            }

            success = db.update_course_outcome(outcome_id, update_data)
            if success:
                logger.info(
                    f"CLO {outcome_id} submitted for approval by user {user_id}"
                )
            else:
                logger.error(f"Failed to update CLO {outcome_id} status")

            return success

        except Exception as e:
            logger.error(f"Error submitting CLO for approval: {e}")
            return False

    @staticmethod
    def approve_clo(outcome_id: str, reviewer_id: str) -> bool:
        """
        Approve a CLO that has been submitted for review.

        Args:
            outcome_id: The ID of the course outcome to approve
            reviewer_id: The ID of the reviewing admin

        Returns:
            bool: True if approval successful, False otherwise
        """
        try:
            outcome = db.get_course_outcome(outcome_id)
            if not outcome:
                logger.error(f"CLO not found: {outcome_id}")
                return False

            # Verify CLO is in a state that can be approved
            if outcome.get("status") not in [
                CLOStatus.AWAITING_APPROVAL,
                CLOStatus.APPROVAL_PENDING,
            ]:
                logger.warning(
                    f"CLO {outcome_id} is in {outcome.get('status')} state, "
                    f"cannot approve"
                )
                return False

            # Update status and review metadata
            # Note: Preserve feedback_comments and feedback_provided_at for audit trail
            update_data = {
                "status": CLOStatus.APPROVED,
                "approval_status": CLOApprovalStatus.APPROVED,
                "reviewed_at": datetime.utcnow(),
                "reviewed_by_user_id": reviewer_id,
            }

            success = db.update_course_outcome(outcome_id, update_data)
            if success:
                logger.info(f"CLO {outcome_id} approved by reviewer {reviewer_id}")
            else:
                logger.error(f"Failed to approve CLO {outcome_id}")

            return success

        except Exception as e:
            logger.error(f"Error approving CLO: {e}")
            return False

    @staticmethod
    def request_rework(
        outcome_id: str, reviewer_id: str, comments: str, send_email: bool = False
    ) -> bool:
        """
        Request rework on a submitted CLO with feedback comments.

        Args:
            outcome_id: The ID of the course outcome needing rework
            reviewer_id: The ID of the reviewing admin
            comments: Feedback comments explaining what needs to be fixed
            send_email: Whether to send email notification to the instructor

        Returns:
            bool: True if rework request successful, False otherwise
        """
        try:
            outcome = db.get_course_outcome(outcome_id)
            if not outcome:
                logger.error(f"CLO not found: {outcome_id}")
                return False

            # Verify CLO is in a state that can be sent back for rework
            if outcome.get("status") not in [
                CLOStatus.AWAITING_APPROVAL,
                CLOStatus.APPROVAL_PENDING,
            ]:
                logger.warning(
                    f"CLO {outcome_id} is in {outcome.get('status')} state, "
                    f"cannot request rework"
                )
                return False

            # Update status and feedback
            update_data = {
                "status": CLOStatus.APPROVAL_PENDING,
                "approval_status": CLOApprovalStatus.NEEDS_REWORK,
                "reviewed_at": datetime.utcnow(),
                "reviewed_by_user_id": reviewer_id,
                "feedback_comments": comments,
                "feedback_provided_at": datetime.utcnow(),
            }

            success = db.update_course_outcome(outcome_id, update_data)
            if not success:
                logger.error(f"Failed to request rework for CLO {outcome_id}")
                return False

            logger.info(
                f"CLO {outcome_id} sent back for rework by reviewer {reviewer_id}"
            )

            # Send email notification if requested
            if send_email:
                CLOWorkflowService._send_rework_notification(outcome_id, comments)

            return True

        except Exception as e:
            logger.error(f"Error requesting rework for CLO: {e}")
            return False

    @staticmethod
    def _send_rework_notification(outcome_id: str, feedback: str) -> bool:
        """
        Send email notification to instructor about rework request.

        Args:
            outcome_id: The ID of the course outcome
            feedback: The feedback comments

        Returns:
            bool: True if email sent successfully, False otherwise
        """
        try:
            # Get outcome with related course/instructor details
            outcome_details = CLOWorkflowService.get_outcome_with_details(outcome_id)
            if not outcome_details:
                logger.error(f"Could not load outcome details for {outcome_id}")
                return False

            instructor_email = outcome_details.get("instructor_email")
            if not instructor_email:
                logger.error(f"No instructor email found for outcome {outcome_id}")
                return False

            course_number = outcome_details.get("course_number", "Unknown Course")
            clo_number = outcome_details.get("clo_number", "Unknown CLO")

            # Compose email
            subject = f"Feedback on CLO {clo_number} for {course_number}"
            text_body = f"""
Hello,

Your submission for Course Learning Outcome {clo_number} in {course_number} requires some revisions before it can be approved.

Feedback from reviewer:
{feedback}

Please review the feedback, make the necessary updates, and resubmit when ready.

Thank you,
Course Record System
            """.strip()

            html_body = f"""
<html>
<body>
<p>Hello,</p>
<p>Your submission for Course Learning Outcome <strong>{clo_number}</strong> in <strong>{course_number}</strong> requires some revisions before it can be approved.</p>
<p><strong>Feedback from reviewer:</strong></p>
<p>{feedback}</p>
<p>Please review the feedback, make the necessary updates, and resubmit when ready.</p>
<p>Thank you,<br>Course Record System</p>
</body>
</html>
            """.strip()

            # Send email using existing email service
            success = EmailService._send_email(
                to_email=instructor_email,
                subject=subject,
                html_body=html_body,
                text_body=text_body,
            )

            if success:
                logger.info(f"Rework notification sent to {instructor_email}")
            else:
                logger.error(
                    f"Failed to send rework notification to {instructor_email}"
                )

            return success

        except Exception as e:
            logger.error(f"Error sending rework notification: {e}")
            return False

    @staticmethod
    def auto_mark_in_progress(outcome_id: str, user_id: str) -> bool:
        """
        Automatically mark a CLO as in_progress when an instructor starts editing.

        Args:
            outcome_id: The ID of the course outcome
            user_id: The ID of the user editing

        Returns:
            bool: True if status updated, False otherwise
        """
        try:
            outcome = db.get_course_outcome(outcome_id)
            if not outcome:
                logger.error(f"CLO not found: {outcome_id}")
                return False

            current_status = outcome.get("status")

            # Only auto-mark if currently assigned or approval_pending
            if current_status not in [CLOStatus.ASSIGNED, CLOStatus.APPROVAL_PENDING]:
                # Already in progress or submitted, don't change status
                return True

            update_data = {"status": CLOStatus.IN_PROGRESS}
            success = db.update_course_outcome(outcome_id, update_data)

            if success:
                logger.info(f"CLO {outcome_id} automatically marked as in_progress")

            return success

        except Exception as e:
            logger.error(f"Error auto-marking CLO in progress: {e}")
            return False

    @staticmethod
    def get_clos_awaiting_approval(
        institution_id: str, program_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get all CLOs awaiting approval, optionally filtered by program.

        Args:
            institution_id: The institution ID to filter by
            program_id: Optional program ID to filter by

        Returns:
            List of CLO dictionaries with enriched course/instructor data
        """
        try:
            # Get outcomes by status
            outcomes = db.get_outcomes_by_status(
                institution_id=institution_id,
                status=CLOStatus.AWAITING_APPROVAL,
                program_id=program_id,
            )

            # Enrich with course and instructor details
            enriched_outcomes = []
            for outcome in outcomes:
                details = CLOWorkflowService.get_outcome_with_details(
                    outcome["outcome_id"]
                )
                if details:
                    enriched_outcomes.append(details)

            return enriched_outcomes

        except Exception as e:
            logger.error(f"Error getting CLOs awaiting approval: {e}")
            return []

    @staticmethod
    def get_clos_by_status(
        status: str,
        institution_id: str,
        program_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get CLOs filtered by status.

        Args:
            status: The CLO status to filter by
            institution_id: The institution ID to filter by
            program_id: Optional program ID to filter by

        Returns:
            List of CLO dictionaries with enriched data
        """
        try:
            outcomes = db.get_outcomes_by_status(
                institution_id=institution_id,
                status=status,
                program_id=program_id,
            )

            # Enrich with course and instructor details
            enriched_outcomes = []
            for outcome in outcomes:
                details = CLOWorkflowService.get_outcome_with_details(
                    outcome["outcome_id"]
                )
                if details:
                    enriched_outcomes.append(details)

            return enriched_outcomes

        except Exception as e:
            logger.error(f"Error getting CLOs by status: {e}")
            return []

    @staticmethod
    def get_outcome_with_details(outcome_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a course outcome with enriched course and instructor details.

        Args:
            outcome_id: The ID of the course outcome

        Returns:
            Dictionary with outcome data plus course_number, course_title,
            instructor_name, instructor_email, etc.
        """
        try:
            outcome = db.get_course_outcome(outcome_id)
            if not outcome:
                return None

            # Get related course
            course_id = outcome.get("course_id")
            course = db.get_course(course_id) if course_id else None

            # Get instructor from course section
            # Note: This assumes we can find the section from the course
            # In practice, we may need to add section_id to CourseOutcome
            instructor = None
            instructor_email = None
            if course:
                # Try to find the active section for this course
                sections = db.get_sections_by_course(course_id)
                if sections:
                    # Get the first section's instructor
                    section = sections[0]
                    instructor_id = section.get("instructor_id")
                    if instructor_id:
                        instructor = db.get_user(instructor_id)
                        instructor_email = (
                            instructor.get("email") if instructor else None
                        )

            # Build enriched result
            instructor_name = None
            if instructor:
                # User model has display_name, first_name, last_name (not full_name)
                instructor_name = instructor.get("display_name")
                if not instructor_name:
                    first = instructor.get("first_name", "")
                    last = instructor.get("last_name", "")
                    instructor_name = f"{first} {last}".strip() or None

            result = {
                **outcome,
                "course_number": course.get("course_number") if course else None,
                "course_title": course.get("course_title") if course else None,
                "instructor_name": instructor_name,
                "instructor_email": instructor_email,
            }

            return result

        except Exception as e:
            logger.error(f"Error getting outcome with details: {e}")
            return None
