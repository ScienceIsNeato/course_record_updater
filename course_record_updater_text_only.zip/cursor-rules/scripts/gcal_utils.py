"""
Google Calendar Utilities
This script provides functions to add and update events in Google Calendar.
It uses Application Default Credentials (ADC) for authentication.
Ensure you have authenticated via `gcloud auth application-default login`.
"""

import argparse
import datetime
import json
import logging
import os

from dateutil import parser as dateutil_parser  # For robust date/time parsing
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# Setup logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)

SCOPES = ["https://www.googleapis.com/auth/calendar"]
# Use GOOGLE_CALENDAR_ID from environment if set, otherwise default to 'primary'
DEFAULT_CALENDAR_ID = os.environ.get("GOOGLE_CALENDAR_ID", "primary")

# Google Calendar Color IDs (for reference)
# 1: Lavender
# 2: Sage
# 3: Grape
# 4: Flamingo
# 5: Banana
# 6: Tangerine
# 7: Peacock
# 8: Graphite
# 9: Blueberry
# 10: Basil
# 11: Tomato


def get_calendar_service():
    """Authenticates and returns a Google Calendar API service object."""
    creds = None
    try:
        from google.auth import default

        creds, project = default(scopes=SCOPES)
        logging.info(
            f"Successfully loaded Application Default Credentials. Project: {project}"
        )
    except Exception as e:
        logging.error(
            f"Failed to load Application Default Credentials: {e}. Ensure 'gcloud auth application-default login' has been run."
        )
        return None

    try:
        service = build("calendar", "v3", credentials=creds)
        logging.info("Google Calendar service created successfully.")
        return service
    except HttpError as error:
        logging.error(f"An API error occurred while building service: {error}")
        return None
    except Exception as e:
        logging.error(f"An unexpected error occurred while building the service: {e}")
        return None


def add_event_func(
    service,
    summary,
    description,
    start_time_str,
    end_time_str,
    attendees=None,
    calendar_id=DEFAULT_CALENDAR_ID,
    timezone="UTC",
    color_id=None,
    update_if_exists=False,
    all_day=False,
):
    """
    Adds an event or updates an existing one if update_if_exists is True and a match is found.
    Match criteria: same summary and start time on the same day.
    Can create all-day events if `all_day` is True.
    """
    if update_if_exists:
        try:
            # Parse the start time to define a search window for the day
            # We need to be careful with timezones for the search window
            # For simplicity, list events and filter client-side, though server-side filtering is better for performance.
            # Let's get events for a +/- 12 hour window around start_time for the given calendar_id to be safe for finding the day's events

            # Define search window for the day of the event in UTC to be safe with timeMin/timeMax
            # This requires converting the event's local start time to UTC for the beginning of that day,
            # and end of that day. This is complex due to timezones.
            # A simpler, though less performant approach for now: list more events and filter.
            # Or, assume the provided timezone is correct and construct the day range.

            # Let's list events for the target calendar.
            # For a robust solution, one would paginate through all events or use a more precise timeMin/timeMax.
            # Given the context, let's try to find events around the given start_time.
            # A common pattern for "day of" is to use timeMin = start of day, timeMax = end of day in event's timezone.
            # For now, let's fetch some events and filter. This is not ideal for performance.

            logging.info(
                f"Update-if-exists: Checking for existing events with summary '{summary}' around '{start_time_str}'"
            )

            # Heuristic: Get events starting a bit before and ending a bit after to catch overlaps or close events for the day
            # This is still not a perfect way to get "all events for that day" due to timezone complexities
            # and how 'day' is defined. A full day query in event's local timezone is needed.
            # For now, let's assume we can find it if it's very close.

            # A better way for finding events on a specific day:
            # 1. Parse start_time_str into a datetime object, aware of its timezone.
            # 2. Normalize this to the beginning of the day in that timezone.
            # 3. Create timeMin for list query (start of day UTC).
            # 4. Create timeMax for list query (end of day UTC).

            # For simplicity for this modification, we'll match summary and exact start_time_str
            # This won't find events if their start_time_str representation differs but time is the same.
            # A proper solution would parse and compare datetime objects.

            events_result = (
                service.events()
                .list(
                    calendarId=calendar_id,
                    singleEvents=True,
                    orderBy="startTime",
                    maxResults=250,
                )
                .execute()
            )  # Get more results
            existing_events = events_result.get("items", [])

            # Create an aware datetime object for the new event for comparison
            try:
                new_event_start_datetime_naive = dateutil_parser.parse(
                    start_time_str
                )  # Parses the time part
                # We need a library that can reliably combine naive time with a timezone string like pytz or use Python 3.9+ zoneinfo
                # For now, we'll rely on isoparse for existing events and direct string comparison if formats are consistent.
                # THIS IS A SIMPLIFICATION AND MIGHT NOT BE ROBUST ACROSS ALL TIMEZONE NUANCES.
                # A fully robust solution would involve pytz or zoneinfo for localization.
            except ValueError:
                logging.error(
                    f"Could not parse provided start_time_str: {start_time_str} for comparison."
                )
                # Fallback to creating new event
                return add_event_func(
                    service,
                    summary,
                    description,
                    start_time_str,
                    end_time_str,
                    attendees,
                    calendar_id,
                    timezone,
                    color_id,
                    update_if_exists=False,
                )  # Call itself to create, ensuring update_if_exists is false

            for ex_event in existing_events:
                ex_summary = ex_event.get("summary")
                ex_start_obj = ex_event.get("start", {})
                ex_start_dt_api_str = ex_start_obj.get(
                    "dateTime"
                )  # This is typically full ISO8601 with offset

                if (
                    not ex_start_dt_api_str
                ):  # Skip all-day events or those without specific dateTime
                    continue

                try:
                    existing_event_start_dt = dateutil_parser.isoparse(
                        ex_start_dt_api_str
                    )

                    # For the new event, we need to construct its effective start time string as the API would see it
                    # For comparison, let's try to see if the API would store our input start_time_str + timezone in the same way
                    # This comparison is tricky. The ideal way is to compare UTC timestamps.

                    # Convert both to UTC for reliable comparison
                    new_event_start_dt_aware = dateutil_parser.parse(
                        start_time_str
                    )  # Naive at first
                    # This step needs a proper timezone library (pytz or zoneinfo) to make naive datetime aware
                    # For now, let's compare the core time and hope the timezone matches in context or that isoparse handles it.
                    # A simplified, potentially less robust comparison due to timezone complexities:
                    # If start_time_str is "YYYY-MM-DDTHH:MM:SS" and timezone is, e.g., "America/Chicago"
                    # existing_event_start_dt is already aware from isoparse(api_response_which_includes_offset)

                    # Let's refine: parse the new start time and then make it aware using the provided timezone.
                    # This requires `pytz` for full robustness with historical timezone data. Python's built-in `timezone` objects are fixed-offset.
                    # Given the constraints of not adding more dependencies *right now* without confirmation,
                    # I will stick to comparing the ISO string representations if possible, or UTC times.

                    # For robust comparison: Convert both to UTC and compare
                    # 1. Parse new_event_start_time_str. If naive, localize with `timezone`, then convert to UTC.
                    # 2. existing_event_start_dt is already aware. Convert to UTC.

                    new_event_start_dt = dateutil_parser.parse(
                        start_time_str
                    )  # This is naive
                    # We can't reliably make it aware and compare without pytz or similar.
                    # Let's assume for this pass that if the summary matches, and the dateutil_parser.isoparse of the existing event
                    # has a date and time that matches our naive new_event_start_dt's date and time parts, AND the timezones are the same,
                    # it's a match. This is still not perfect.

                    if (
                        ex_summary == summary
                        and existing_event_start_dt.year == new_event_start_dt.year
                        and existing_event_start_dt.month == new_event_start_dt.month
                        and existing_event_start_dt.day == new_event_start_dt.day
                        and existing_event_start_dt.hour == new_event_start_dt.hour
                        and existing_event_start_dt.minute == new_event_start_dt.minute
                        and existing_event_start_dt.second == new_event_start_dt.second
                        and ex_start_obj.get("timeZone", timezone) == timezone
                    ):  # Compare timezone field too

                        event_id_to_update = ex_event["id"]
                        logging.info(
                            f"Found existing event with ID: {event_id_to_update} based on summary, date/time parts, and timezone. Updating it."
                        )
                        return update_event_func(
                            service,
                            event_id_to_update,
                            summary,
                            description,
                            start_time_str,
                            end_time_str,
                            attendees,
                            calendar_id,
                            timezone,
                            color_id,
                        )
                except Exception as e_parse:
                    logging.warning(
                        f"Could not parse/compare date for event {ex_event.get('id')}: {e_parse}"
                    )
                    continue

            logging.info("No exact match found. Proceeding to create a new event.")

        except HttpError as e_list:
            logging.error(
                f"API error when trying to list events for update_if_exists: {e_list}"
            )
            # Fallback to creating a new event if listing fails
        except Exception as e_general:
            logging.error(
                f"Unexpected error during update_if_exists check: {e_general}"
            )
            # Fallback

    event = {
        "summary": summary,
        "description": (
            description.replace("%%NL%%", "\n").replace("\\n", "\n")
            if description
            else ""
        ),
    }

    if all_day:
        # Use date field for all-day events
        # Assuming start_time_str and end_time_str are in YYYY-MM-DD format for all-day
        event["start"] = {"date": start_time_str}
        event["end"] = {"date": end_time_str}
    else:
        # Use dateTime field for timed events
        event["start"] = {"dateTime": start_time_str, "timeZone": timezone}
        event["end"] = {"dateTime": end_time_str, "timeZone": timezone}

    if attendees:
        event["attendees"] = [{"email": email} for email in attendees]
    if color_id:
        event["colorId"] = str(color_id)

    logging.info(f"Attempting to add event with body: {json.dumps(event, indent=2)}")
    try:
        created_event = (
            service.events().insert(calendarId=calendar_id, body=event).execute()
        )
        logging.info(
            f"Event created successfully. Full API response: {json.dumps(created_event, indent=2)}"
        )
        print(f"Event created: {created_event.get('htmlLink')}")
        return created_event
    except HttpError as error:
        logging.error(f"An API error occurred while adding event: {error}")
        print(f"Error adding event: {error}")
        return None
    except Exception as e:
        logging.error(f"An unexpected error occurred while adding event: {e}")
        print(f"Error adding event: {e}")
        return None


def update_event_func(
    service,
    event_id,
    summary=None,
    description=None,
    start_time_str=None,
    end_time_str=None,
    attendees=None,
    calendar_id=DEFAULT_CALENDAR_ID,
    timezone="UTC",
    color_id=None,
    all_day=None,
):
    """
    Updates an existing event using an existing service object.
    Can update an event to be all-day or timed.
    """
    try:
        event_to_update = (
            service.events().get(calendarId=calendar_id, eventId=event_id).execute()
        )

        # Apply updates
        if summary is not None:
            event_to_update["summary"] = summary
        if description is not None:
            event_to_update["description"] = description.replace(
                "%%NL%%", "\n"
            ).replace("\\n", "\n")

        # Handle all_day/timed update logic
        if all_day is not None:
            if all_day:
                # Convert to all-day. Use date part from provided strings if available, otherwise keep existing date parts.
                start_date = (
                    start_time_str.split("T")[0]
                    if start_time_str
                    else event_to_update["start"].get(
                        "date",
                        event_to_update["start"].get("dateTime", "").split("T")[0],
                    )
                )
                end_date = (
                    end_time_str.split("T")[0]
                    if end_time_str
                    else event_to_update["end"].get(
                        "date", event_to_update["end"].get("dateTime", "").split("T")[0]
                    )
                )
                event_to_update["start"] = {"date": start_date}
                event_to_update["end"] = {"date": end_date}
                # Remove dateTime and timeZone if they exist from previous state
                if "dateTime" in event_to_update["start"]:
                    del event_to_update["start"]["dateTime"]
                if "timeZone" in event_to_update["start"]:
                    del event_to_update["start"]["timeZone"]
                if "dateTime" in event_to_update["end"]:
                    del event_to_update["end"]["dateTime"]
                if "timeZone" in event_to_update["end"]:
                    del event_to_update["end"]["timeZone"]
            else:
                # Convert to timed. Requires time strings.
                if start_time_str is not None and end_time_str is not None:
                    event_to_update["start"] = {
                        "dateTime": start_time_str,
                        "timeZone": timezone,
                    }
                    event_to_update["end"] = {
                        "dateTime": end_time_str,
                        "timeZone": timezone,
                    }
                    # Remove date if it exists from previous state
                    if "date" in event_to_update["start"]:
                        del event_to_update["start"]["date"]
                    if "date" in event_to_update["end"]:
                        del event_to_update["end"]["date"]
                elif (
                    "date" in event_to_update["start"]
                    or "date" in event_to_update["end"]
                ):
                    logging.warning(
                        "Cannot convert to timed event without providing start and end time strings."
                    )
                    # Keep existing all-day status if cannot convert

        else:  # all_day is None, update only time/date fields if provided
            if (
                start_time_str is not None
            ):  # This assumes start_time_str is appropriate format (date or dateTime)
                if (
                    "date" in event_to_update["start"]
                ):  # If existing is all-day, update date
                    event_to_update["start"]["date"] = start_time_str.split("T")[
                        0
                    ]  # Assume new string is at least date part
                else:  # If existing is timed, update dateTime and timezone
                    event_to_update["start"] = {
                        "dateTime": start_time_str,
                        "timeZone": timezone,
                    }

            if end_time_str is not None:
                if (
                    "date" in event_to_update["end"]
                ):  # If existing is all-day, update date
                    event_to_update["end"]["date"] = end_time_str.split("T")[
                        0
                    ]  # Assume new string is at least date part
                else:  # If existing is timed, update dateTime and timezone
                    event_to_update["end"] = {
                        "dateTime": end_time_str,
                        "timeZone": timezone,
                    }

        if attendees is not None:
            event_to_update["attendees"] = [{"email": email} for email in attendees]
        elif (
            "attendees" in event_to_update and attendees == []
        ):  # Explicitly clear if empty list provided
            del event_to_update["attendees"]

        if color_id is not None:
            event_to_update["colorId"] = str(color_id)
        elif (
            "colorId" in event_to_update and color_id is None
        ):  # If color_id is explicitly passed as None (though CLI won't do this)
            pass  # Keep existing or let API default if not present

        logging.info(
            f"Attempting to update event {event_id} with body: {json.dumps(event_to_update, indent=2)}"
        )
        updated_event = (
            service.events()
            .update(calendarId=calendar_id, eventId=event_id, body=event_to_update)
            .execute()
        )
        logging.info(
            f"Event updated successfully. Full API response: {json.dumps(updated_event, indent=2)}"
        )
        print(f"Event updated: {updated_event.get('htmlLink')}")
        return updated_event
    except HttpError as error:
        logging.error(f"An API error occurred while updating event: {error}")
        print(f"Error updating event: {error}")
        if error.resp.status == 404:
            logging.error(
                f"Event with ID '{event_id}' not found in calendar '{calendar_id}'."
            )
        return None
    except Exception as e:
        logging.error(f"An unexpected error occurred while updating event: {e}")
        print(f"Error updating event: {e}")
        return None

def list_events_func(service, calendar_id=DEFAULT_CALENDAR_ID, max_results=10, start_date_str=None):
    """Lists upcoming events using an existing service object."""
    now = datetime.datetime.utcnow().isoformat() + "Z"  # 'Z' indicates UTC time
    logging.info(f"Getting the upcoming {max_results} events from {calendar_id}")
    print(f"Getting the upcoming {max_results} events from {calendar_id}")
    try:
        events_result = (
            service.events()
            .list(
                calendarId=calendar_id,
                timeMin=now,
                maxResults=max_results,
                singleEvents=True,
                orderBy="startTime",
            )
            .execute()
        )
        events = events_result.get("items", [])

        if not events:
            print("No upcoming events found.")
            return
        for event in events:
            start = event["start"].get("dateTime", event["start"].get("date"))
            print(f"{start} - {event['summary']}")
    except HttpError as error:
        logging.error(f"An API error occurred while listing events: {error}")
        print(f"Error listing events: {error}")
    except Exception as e:
        logging.error(f"An unexpected error occurred while listing events: {e}")
        print(f"Error listing events: {e}")


def find_event_id_func(service, summary, date_str, calendar_id=DEFAULT_CALENDAR_ID):
    """
    Finds an event ID based on summary and date.
    Searches for events on the specified date.
    Returns the ID of the first match, or None if not found.
    Logs a warning if multiple events match.
    """
    try:
        # Define time range for the specific day
        time_min = f"{date_str}T00:00:00Z"  # Start of the day in UTC
        time_max = f"{date_str}T23:59:59Z"  # End of the day in UTC

        # List events within the time range
        events_result = (
            service.events()
            .list(
                calendarId=calendar_id,
                timeMin=time_min,
                timeMax=time_max,
                singleEvents=True,
                orderBy="startTime",
                q=summary,  # Use query parameter for text search
            )
            .execute()
        )

        events = events_result.get("items", [])

        matching_events = []
        for event in events:
            # Simple check for summary match, could be more robust
            if event.get("summary") == summary:
                matching_events.append(event)

        if not matching_events:
            logging.info(f"No event found with summary '{summary}' on {date_str}")
            return None
        elif len(matching_events) > 1:
            logging.warning(
                f"Multiple events found with summary '{summary}' on {date_str}. Returning the first one."
            )
            # Optionally list all matching event IDs
            for event in matching_events:
                logging.warning(f"Matching event ID: {event.get('id')}")
            return matching_events[0].get("id")
        else:
            logging.info(
                f"Found event with summary '{summary}' on {date_str}, ID: {matching_events[0].get('id')}"
            )
            return matching_events[0].get("id")

    except HttpError as error:
        logging.error(f"An API error occurred while searching for event: {error}")
        print(f"Error searching for event: {error}")
        return None
    except Exception as e:
        logging.error(f"An unexpected error occurred while searching for event: {e}")
        print(f"Error searching for event: {e}")
        return None

def delete_event_func(service, event_id, calendar_id=DEFAULT_CALENDAR_ID):
    """
    Deletes an event from the calendar.
    """
    try:
        logging.info(f"Attempting to delete event {event_id} from {calendar_id}")
        service.events().delete(calendarId=calendar_id, eventId=event_id).execute()
        logging.info(f"Successfully deleted event {event_id} from {calendar_id}")
        print(f"Event deleted: {event_id}")
        return True
    except HttpError as error:
        logging.error(f'An API error occurred while deleting event: {error}')
        print(f"Error deleting event: {error}")
        if error.resp.status == 404:
            logging.error(f"Event with ID '{event_id}' not found in calendar '{calendar_id}'.")
        return False
    except Exception as e:
        logging.error(f'An unexpected error occurred while deleting event: {e}')
        print(f"Error deleting event: {e}")
        return False

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Manage Google Calendar events.")
    parser.add_argument("action", choices=['add', 'update', 'list', 'find_id', 'delete'], help="Action to perform.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Manage Google Calendar events.")
    # Corrected choices to include list and find_id
    parser.add_argument(
        "action",
        choices=["add", "update", "list", "find_id"],
        help="Action to perform.",
    )

    # Arguments for 'add', 'update', and 'delete' actions
    # Arguments for 'add' and 'update' actions
    parser.add_argument("--summary", help="Summary for the event.")
    parser.add_argument("--description", default="", help="Description for the event.")
    parser.add_argument(
        "--start_time",
        help="Start time for the event (ISO 8601 format: YYYY-MM-DDTHH:MM:SS or YYYY-MM-DD for all day).",
    )
    parser.add_argument(
        "--end_time",
        help="End time for the event (ISO 8601 format: YYYY-MM-DDTHH:MM:SS or YYYY-MM-DD for all day). Required for timed events.",
    )
    parser.add_argument(
        "--timezone", default="UTC", help="Timezone for the event (default: UTC)."
    )
    parser.add_argument("--attendees", nargs="*", help="Email addresses of attendees.")
    parser.add_argument(
        "--calendar_id",
        default=DEFAULT_CALENDAR_ID,
        help=f"Calendar ID (default: {DEFAULT_CALENDAR_ID}).",
    )
    parser.add_argument("--color_id", help="Color ID for the event (1-11).")
    parser.add_argument(
        "--update_if_exists",
        action="store_true",
        help="For 'add' action, update if an event with the same summary and start time exists.",
    )
    parser.add_argument(
        "--all_day",
        action="store_true",
        help="Set the event as an all-day event. Requires YYYY-MM-DD format for start_time and end_time.",
    )

    # Arguments for 'update' action
    parser.add_argument(
        "--event_id", help="Event ID to update (required for 'update' action)."
    )

    # Arguments for 'find_id' action
    parser.add_argument(
        "--date",
        help="Date to search for the event (YYYY-MM-DD). Required for 'find_id' action.",
    )

    # Arguments for 'list' action
    parser.add_argument("--max_results", type=int, default=10, help="Maximum number of events to list (default: 10).")
    parser.add_argument("--start_date", help="Start date to list events from (YYYY-MM-DD).")

    args = parser.parse_args()

    service = get_calendar_service()

    if not service:
        print("Failed to get calendar service.")
        exit(1)

    if args.action == "add":
        if (
            not args.summary
            or not args.start_time
            or (not args.all_day and not args.end_time)
        ):
            print(
                "Error: For 'add' action, --summary and --start_time are required. --end_time is required for timed events."
            )
            exit(1)
        add_event_func(
            service,
            args.summary,
            args.description,
            args.start_time,
            args.end_time,
            args.attendees,
            args.calendar_id,
            args.timezone,
            args.color_id,
            args.update_if_exists,
            args.all_day,
        )

    elif args.action == "update":
        if not args.event_id:
            print("Error: --event_id is required for 'update' action.")
            exit(1)
        # For update, we allow updating only some fields
        update_event_func(
            service,
            args.event_id,
            args.summary,
            args.description,
            args.start_time,
            args.end_time,
            args.attendees,
            args.calendar_id,
            args.timezone,
            args.color_id,
            args.all_day,
        )

    elif args.action == 'list': # Added list action handler
        list_events_func(service, args.calendar_id, args.max_results, args.start_date)
        
    elif args.action == 'find_id':
        if not args.summary or not args.date:
            print(
                "Error: For 'find_id' action, --summary and --date (YYYY-MM-DD) are required."
            )
            exit(1)
        event_id = find_event_id_func(
            service, args.summary, args.date, args.calendar_id
        )
        if event_id:
            print(f"Found event ID: {event_id}")
        else:
            print("Event not found.")
            
    elif args.action == 'delete': # Added delete action handler
        if not args.event_id:
            print("Error: --event_id is required for 'delete' action.")
            exit(1)
        delete_event_func(service, args.event_id, args.calendar_id) 
